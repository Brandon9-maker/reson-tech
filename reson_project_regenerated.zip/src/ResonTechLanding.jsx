// Placeholder ResonTechLanding component
export default function ResonTechLanding(){
  return <div style={{padding:40,fontSize:40}}>RESON TECH UI COMPONENT PLACEHOLDER</div>;
}
